-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 21, 2020 at 11:41 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `supportivelearning`
--

-- --------------------------------------------------------

--
-- Table structure for table `assignment`
--

CREATE TABLE `assignment` (
  `id` int(11) NOT NULL,
  `AssName` varchar(50) NOT NULL,
  `AssStartDate` varchar(50) NOT NULL,
  `AssEndDate` varchar(50) NOT NULL,
  `AssDescription` varchar(255) NOT NULL,
  `AssFile` varchar(255) NOT NULL,
  `Batch_Code` varchar(50) NOT NULL,
  `Subject` varchar(50) NOT NULL,
  `Upload` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assignment`
--

INSERT INTO `assignment` (`id`, `AssName`, `AssStartDate`, `AssEndDate`, `AssDescription`, `AssFile`, `Batch_Code`, `Subject`, `Upload`) VALUES
(10, 'Form', '13/ 11 / 2020', '16 /11 /2020', ' your form submissions and distinguish between multiple forms on your Site Solution site, if you choose to add them. ... Use this space to briefly describe your goal for the f', '../AssFiles/CV.pdf', '1810G1', 'PHP', 'Samreen'),
(11, 'Role Based ', '17/ 11 / 2020', '2020-11-18', 'Role-based access control (RBAC) restricts network access based on a person\'s role within an organization', '../AssFiles/p5.PNG', '1910F1', 'PHP', 'Samreen'),
(12, 'CRUD Operation', '20/ 11 / 2020', '2020-11-22', 'CRUD is an acronym that comes from the world of computer programming and refers to the four functions that are considered necessary to implement a persistent storage application: create, read, update and delete.', '../AssFiles/Assignment 2.pdf', '1810G2', 'PHP', 'Ali'),
(13, 'Db connection', '20/ 11 / 2020', '2020-11-18', 'A database is an organized collection of data, generally stored and accessed electronically from a computer system. Where databases are more complex they are often developed using formal design and modeling techniques.', '../AssFiles/Assignment 3.pdf', '1910F1', 'JAVA', 'Owais');

-- --------------------------------------------------------

--
-- Table structure for table `batch_code`
--

CREATE TABLE `batch_code` (
  `id` int(11) NOT NULL,
  `Batch_Code` varchar(50) NOT NULL,
  `TotalStudent` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `batch_code`
--

INSERT INTO `batch_code` (`id`, `Batch_Code`, `TotalStudent`) VALUES
(1, '1810G2', 20),
(2, '1810G1', 20),
(3, '1910F1', 15),
(4, '1910F2', 10);

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE `faqs` (
  `id` int(11) NOT NULL,
  `Question` varchar(50) NOT NULL,
  `Answer` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faqs`
--

INSERT INTO `faqs` (`id`, `Question`, `Answer`) VALUES
(1, 'How to check the assignment?', 'Video provides a powerful way to help you prove your point. When you click Online Video, you can paste in the embed code for the video you want to add. You can also type a keyword to search online for the video that best fits your document.'),
(2, 'How to download the assignment?', 'To make your document look professionally produced, Word provides header, footer, cover page, and text box designs that complement each other. For example, you can add a matching cover page, header, and sidebar. Click Insert and then choose the elements you want from the different galleries.'),
(3, ' How to submit the assignment?', 'By pressing submit button.'),
(4, 'How to check the marks?', 'Save time in Word with new buttons that show up where you need them. To change the way a picture fits in your document, click it and a button for layout options appears next to it. When you work on a table, click where you want to add a row or a column, and then click the plus sign.'),
(5, 'How to post a query?', 'Reading is easier, too, in the new Reading view. You can collapse parts of the document and focus on the text you want. If you need to stop reading before you reach the end, Word remembers where you left off - even on another device.\r\n\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `id` int(11) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `DOB` varchar(50) NOT NULL,
  `Gender` varchar(7) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Role` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `FirstName`, `LastName`, `DOB`, `Gender`, `Email`, `Password`, `Role`) VALUES
(1, 'Abdul', 'Wahab', '17/10/1993', 'Male', 'wahab@gmail.com', '123', 'Admin'),
(2, 'Miss', 'Samreen', '26/01/1994', 'Female', 'samreen@gmail.com', '789', 'Faculty'),
(8, 'Owais', 'Khan', '02/11/2001', 'Male', 'owais@gmail.com', '789', 'Faculty'),
(9, 'Ali', 'Raza', '04/11/1992', 'Male', 'aliraza@gmail.com', '234', 'Faculty');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `StudentName` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Batch_Code` varchar(50) NOT NULL,
  `Year` year(4) NOT NULL,
  `Semester` varchar(50) NOT NULL,
  `Role` varchar(10) NOT NULL,
  `EnrollmentNo` varchar(100) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`StudentName`, `Email`, `Password`, `Batch_Code`, `Year`, `Semester`, `Role`, `EnrollmentNo`, `id`) VALUES
('Abdullah', 'abdullah@gmail.com', '456', '1910F2', 2016, '2', 'Student', 'AbdullahB1910F2Y2016', 7),
('adnan', 'adnan@gmail.com', '123', '1810G2', 2017, '4', 'Student', 'adnanB1810G2Y2017', 5),
('Faizan', 'faizan@gmail.com', '890', '1910F2', 2019, '6', 'Student', 'FaizanB1910F2Y2019', 6),
('Rizwan', 'rizwan@gmail.com', '890', '1910F1', 2019, '5', 'Student', 'RizwanB1910F1Y2019', 8),
('sandaaleen', 'saad@outlook.com', 'ty', '1810G1', 2019, '5', 'Student', 'sandaaleenB1810G1Y2019', 2),
('Shahtaj', 'shahtaj@gmail.com', '789', '1810G2', 2020, '1', 'Student', 'ShahtajB1810G2Y2020', 4),
('Sufyan', 'Sufyan@gmail.com', '567', '1810G2', 2018, '2', 'Student', 'SufyanB1810G2Y2018', 3),
('Taimoor', 'taimoor@gmail.com', 'taim', '1910F1', 2020, '2', 'Student', 'TaimoorB1910F1Y2020', 9),
('Waqas', 'waqas@gmail.com', 'hj', '1810G2', 2018, '2', 'Student', 'WaqasB1810G2Y2018', 1);

-- --------------------------------------------------------

--
-- Table structure for table `studentmarks`
--

CREATE TABLE `studentmarks` (
  `id` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Marks` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `studentmarks`
--

INSERT INTO `studentmarks` (`id`, `Name`, `Marks`) VALUES
(9, 'sandaaleen', 80),
(10, 'Rizwan', 40);

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `id` int(11) NOT NULL,
  `Subject` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`id`, `Subject`) VALUES
(1, 'JAVA'),
(2, 'PHP'),
(3, 'c#'),
(4, 'SQL');

-- --------------------------------------------------------

--
-- Table structure for table `submitassignment`
--

CREATE TABLE `submitassignment` (
  `id` int(11) NOT NULL,
  `StudentName` varchar(50) NOT NULL,
  `AssignmentName` varchar(50) NOT NULL,
  `SubmisionDate` varchar(30) NOT NULL,
  `File` varchar(255) NOT NULL,
  `Marks` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `submitassignment`
--

INSERT INTO `submitassignment` (`id`, `StudentName`, `AssignmentName`, `SubmisionDate`, `File`, `Marks`) VALUES
(11, 'sandaaleen', 'Form', '16/ 11 / 2020', '../AssFiles/CV.pdf', 90),
(12, 'Yousuf', 'Role Based ', '17/ 11 / 2020', '../SubmitAssignment/Assignment 1.pdf', 60),
(13, 'Rizwan', 'Role Based ', '20/ 11 / 2020', '../SubmitAssignment/Assignment 1.pdf', 60);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assignment`
--
ALTER TABLE `assignment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `batch_code`
--
ALTER TABLE `batch_code`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faqs`
--
ALTER TABLE `faqs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`EnrollmentNo`),
  ADD UNIQUE KEY `uniqueid` (`id`);

--
-- Indexes for table `studentmarks`
--
ALTER TABLE `studentmarks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `submitassignment`
--
ALTER TABLE `submitassignment`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assignment`
--
ALTER TABLE `assignment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `batch_code`
--
ALTER TABLE `batch_code`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `faqs`
--
ALTER TABLE `faqs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `studentmarks`
--
ALTER TABLE `studentmarks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `submitassignment`
--
ALTER TABLE `submitassignment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
